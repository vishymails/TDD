package com.bvr;

public class Calculator {

	public boolean isEvenNumber(int number) {
		return number % 2 == 0;
	}
	
}