package com.bvr.mockito;

public class UserManager {

	public int getUserCount() {
		return 0;
	}
	
	public void save(String name) {
		
	}
}
