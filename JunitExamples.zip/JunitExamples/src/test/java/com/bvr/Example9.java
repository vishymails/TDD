package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.bvr.model.Book;
import com.bvr.service.BookService;

@Disabled("Skipped issue has been fixed ")
public class Example9 {

	@Test
	public void assertEqualsWithNoMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		Book actualBook = bookService.getBookById("1");
		
		assertEquals("1", actualBook.getBookId());
		assertEquals("Basic Java", actualBook.getTitle());
		
		
	}
	
	
	
	@Test
	public void assertEqualsWithMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		Book actualBook = bookService.getBookById("1");
		
		assertEquals("1", actualBook.getBookId());
		assertEquals("Basic Java1", actualBook.getTitle(), "Book title Didnot match!");
		
		
	}
	
}
