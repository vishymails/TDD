package com.bvr;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;

import com.bvr.mockito2.AuthenticationService;
import com.bvr.mockito2.UserRepository;

@TestInstance(Lifecycle.PER_CLASS)
public class Example23 {

    private AuthenticationService service; // SUT

    private UserRepository repository;  // mock

    @BeforeAll
    public void setUp() {
        this.repository = Mockito.mock(UserRepository.class);
        this.service = new AuthenticationService(repository);
    }

    @Test
    public void testAuthenticate() {
        // arrange
        Mockito.when(this.repository.findByUsername(Mockito.anyString())).thenThrow(new IllegalArgumentException());

        // act
        this.service.authenticate("harry", "harry12345");

        // assert
    }

}


