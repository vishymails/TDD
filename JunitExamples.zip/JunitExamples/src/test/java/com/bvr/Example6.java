package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertTimeout;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.bvr.model.Book;
import com.bvr.service.BookService;

public class Example6 {

	@Test
	public void assertIteratableEqualsWithNoMessage() {
		Book book1 = new Book("1", "Basic Java", "Wrox");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		Book book3 = new Book("3", "Head First Javascript", "Wrox");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		bookService.addBook(book3);
		
		List<String> actualTitles = bookService.getBookTitlesByPublisher("Wrox");
		
		List<String> expectedTitles = new ArrayList<>();
		
		expectedTitles.add("Basic Java");
		expectedTitles.add("Head First Javascript");
		
		assertIterableEquals(expectedTitles, actualTitles);
		
		
		
	}
	
	
	
	@Test
	public void assertTimeoutWithNoMessage() {
		BookService bookService = new BookService();
		
		for(int i = 1; i<=1000; i++) {
			bookService.addBook(new Book(String.valueOf(i), "Head First Java", "Wrox"));
		}
		
		
		List<String> actualTitles = new ArrayList<>();
		
		
		assertTimeout(Duration.ofMillis(1), () -> {
			actualTitles.addAll(bookService.getBookTitlesByPublisher("Wrox"));
		});
		
		
		assertEquals(1000, actualTitles.size());
		
	}
	
	
}
