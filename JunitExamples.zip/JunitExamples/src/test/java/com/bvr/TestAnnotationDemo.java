package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class TestAnnotationDemo {

	@Test
	void test() {
		assertEquals(3, 3);
	}
	
	@Test
	void test1() {
		assertEquals(3, 2);
	}
}
