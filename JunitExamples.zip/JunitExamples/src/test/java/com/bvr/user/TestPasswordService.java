package com.bvr.user;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
public class TestPasswordService {
	
	@Test
	public void changePassword() {
		assertEquals(1,1);
	}

}
