package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("@Display Name annotation for class")
public class Example10 {
	
	@Test
	@DisplayName("Display Name for Test Method 1")
	public void displayNameDemoTest() {
		assertEquals(3, 2+1);
	}

	@Test
	@DisplayName("Display Name for Test Method 1 Ñ ⌠ ► ó ")
	public void displayNameDemoTest2() {
		assertEquals(3, 2+1);
	}
	
	
	@Test
	@DisplayName("Display Name for Test Method 1 Ñ ⌠ ► ó 🐶")
	public void displayNameDemoTest3() {
		assertEquals(3, 2+1);
	}
	
}
