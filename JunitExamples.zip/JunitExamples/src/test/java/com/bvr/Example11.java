package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import com.bvr.exception.BookNotFoundException;
import com.bvr.model.Book;
import com.bvr.service.BookService;

public class Example11 {

	@Test
	public void assertThrowsWithNoMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		BookNotFoundException bookNotFoundException = assertThrows(BookNotFoundException.class,
				() -> bookService.getBookByTitle("Head First Spring"));
		
		assertEquals("Book not found in Bookstore!", bookNotFoundException.getMessage());
		
		
	}
	
	
	
	@Test
	public void assertThrowsWithMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		assertThrows(BookNotFoundException.class,
				() -> bookService.getBookByTitle("Head First Spring"),
				"Different Exception thrown");
	}
	
	
	
	@Test
	public void assertThrowsWithMessageSupplier() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		assertThrows(BookNotFoundException.class,
				() -> bookService.getBookByTitle("Head First Spring"),
				() -> "Different Exception thrown");
	}
}
