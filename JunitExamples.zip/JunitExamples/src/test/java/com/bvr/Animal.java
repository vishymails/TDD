package com.bvr;

public enum Animal {

	DOG,
	CAT,
	LION,
	TIGER,
	DONKEY
}
