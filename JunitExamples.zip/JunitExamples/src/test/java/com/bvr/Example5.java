package com.bvr;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import com.bvr.model.Book;
import com.bvr.service.BookService;

public class Example5 {
	@Test
	public void assertNullWithNoMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		Book actualBook = bookService.getBookById("4");
		
		assertNull(actualBook);
	}
	
	@Test
	public void assertNullWithMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		Book actualBook = bookService.getBookById("2");
		
		assertNull(actualBook, "Object is not null");
	}
	
	
	@Test
	public void assertNotNullWithMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		Book actualBook = bookService.getBookById("2");
		
		assertNotNull(actualBook, "Object is not null");
	}
}
