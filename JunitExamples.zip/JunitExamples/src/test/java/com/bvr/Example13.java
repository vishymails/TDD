package com.bvr;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class Example13 {

	@RepeatedTest(8)
	public void simpleRepeatedTest() {
		assertTrue(0 < 5);
	}
	
	@BeforeAll
	public void beforeAll() {
		System.out.println(" BeforeAll got executed");
	}
	
	@BeforeEach
	public void beforeEach() {
		System.out.println(" BeforeEach got executed");
	}
	
	
	@AfterAll
	public void afterAll() {
		System.out.println(" AfterAll got executed");
	}
	
	
	@AfterEach
	public void afterEach() {
		System.out.println(" AfterEach got executed");
	}
	
}
