package com.bvr;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.EnumSource.Mode;

public class Example17 {

	@ParameterizedTest
	@EnumSource(value = Animal.class)
	public void enumSourceDemoTest(Animal animal) {
		assertNotNull(animal);
	}
	
	
	@ParameterizedTest
	@EnumSource(value = Animal.class, names= {"DOG", "CAT"})
	public void enumSourceDemoTest1(Animal animal) {
		assertNotNull(animal);
	}
	
	@ParameterizedTest
	@EnumSource(value = Animal.class, mode = Mode.EXCLUDE, names= {"DOG", "CAT"})
	public void enumSourceDemoTest2(Animal animal) {
		assertNotNull(animal);
	}
	
	@ParameterizedTest
	@EnumSource(value = Animal.class,  mode = Mode.MATCH_ALL, names= "^(C|L).+$")
	public void enumSourceDemoTest3(Animal animal) {
		assertNotNull(animal);
	}
	
}
