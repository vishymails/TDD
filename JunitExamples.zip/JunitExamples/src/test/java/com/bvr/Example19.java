package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;

public class Example19 {
	@ParameterizedTest
	@CsvFileSource(resources = "reverse.csv")
	public void csvSourceDemoTest(String input, String expected) {
		StringHelper stringHelper = new StringHelper();
		assertEquals(expected , stringHelper.reverse(input));
	}
	
	@ParameterizedTest
	@CsvFileSource(resources = "reverse.csv", numLinesToSkip = 1)
	public void csvSourceDemoTest1(String input, String expected) {
		StringHelper stringHelper = new StringHelper();
		assertEquals(expected , stringHelper.reverse(input));
	}
	
}
