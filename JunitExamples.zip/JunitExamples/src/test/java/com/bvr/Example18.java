package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class Example18 {

	@ParameterizedTest
	@CsvSource({
		"car, rac",
		"test, tset"
		
	})
	public void csvSourceDemoTest(String input, String expected) {
		StringHelper stringHelper = new StringHelper();
		assertEquals(expected , stringHelper.reverse(input));
	}
	
	
	@ParameterizedTest
	@CsvSource({
		"car, 'my, rac'",
		"test, ''",
		"book, "
		
	})
	public void csvSourceDemoWithSingleQuotesTest(String first, String second) {
		assertNotNull(first);
		assertNotNull(second);
	}
}
