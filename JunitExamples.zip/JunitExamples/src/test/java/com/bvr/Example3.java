package com.bvr;


import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.bvr.model.Book;
import com.bvr.service.BookService;

public class Example3 {

	@Test 
	public void assertTrueWithNoMessage() {
		BookService bookService = new BookService() ;
		
		Book book1 = new Book("1", "Basic Java", "Wrox");
		
		//bookService.addBook(book1);
		
		List<Book> listOfBooks = bookService.books();
		
		assertTrue(listOfBooks.isEmpty());
	}
	
	

	@Test 
	public void assertTrueWithMessage() {
		BookService bookService = new BookService() ;
		
		Book book1 = new Book("1", "Basic Java", "Wrox");
		
		//bookService.addBook(book1);
		
		List<Book> listOfBooks = bookService.books();
		
		assertTrue(listOfBooks.isEmpty(), "List id not empty");
	}
}
