package com.bvr;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;

public class Example14 {

	
	
	@RepeatedTest(8)
	public void simpleRepeatedTest() {
		assertTrue(0 < 5);
	}
	
	
	@RepeatedTest(value = 5, name="{displayName} - {currentRepetition} / {totalRepetitions} ")
	@DisplayName("Repeated Test With Template")
	public void simpleRepeatedTest2() {
		assertTrue(0 < 5);
	}
	
	
	@RepeatedTest(value = 5, name= RepeatedTest.LONG_DISPLAY_NAME)
	@DisplayName("Repeated Test With Template2")
	public void simpleRepeatedTest3() {
		assertTrue(0 < 5);
	}
	
	
	@RepeatedTest(value = 5, name= RepeatedTest.SHORT_DISPLAY_NAME)
	@DisplayName("Repeated Test With Template3")
	public void simpleRepeatedTest4() {
		assertTrue(0 < 5);
	}
}
