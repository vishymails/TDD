package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumingThat;

import org.junit.jupiter.api.Test;

public class Example8 {

	@Test
	public void assumingThatWithBooleanCondition() {
		assumingThat("DEV".equals(System.getProperty("ENV")), () -> {
			System.out.println("Dev Environment");
			assertEquals(5, 3+2);
		});
		
		System.out.println("Executed in every environment is Passed");
		
		assertEquals(3, 2+1);
	}
	
}
