package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.bvr.model.Book;
import com.bvr.service.BookService;

public class Example2 {

	@Test
	public void assertEqualsWithNoMessage() {
		Book book1 = new Book("1", "Basic Java", "Wrox");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		Book book3 = new Book("3", "Head First Javascript", "Wrox");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		bookService.addBook(book3);
		
		String[] actualBookIds = bookService.getBookIdsByPublisher("Wrox");
		
		System.out.println(actualBookIds.toString());
		
		assertEquals(new String[] {"1", "3"}, actualBookIds);
		
		
		
	}
	
	
	
	@Test 
	public void assertFalseWithNoMessage() {
		BookService bookService = new BookService() ;
		
		Book book1 = new Book("1", "Basic Java", "Wrox");
		bookService.addBook(book1);
		
		List<Book> listOfBooks = bookService.books();
		
		assertFalse(listOfBooks.isEmpty());
	}
	
	
	@Test 
	public void assertFalseWithMessage() {
		BookService bookService = new BookService() ;
		
		Book book1 = new Book("1", "Basic Java", "Wrox");
		bookService.addBook(book1);
		
		List<Book> listOfBooks = bookService.books();
		
		assertFalse(listOfBooks.isEmpty(), "List of Books is Empty");
	}
	
	
	@Test 
	public void assertFalseWithSupplierAndMessage() {
		BookService bookService = new BookService() ;
		
		Book book1 = new Book("1", "Basic Java", "Wrox");
		bookService.addBook(book1);
		
		List<Book> listOfBooks = bookService.books();
		
		assertFalse(() -> listOfBooks.isEmpty(), "List of Books is Empty");
	}
	
	
	@Test 
	public void assertFalseWithMessageSupplier() {
		BookService bookService = new BookService() ;
		
		Book book1 = new Book("1", "Basic Java", "Wrox");
		bookService.addBook(book1);
		
		List<Book> listOfBooks = bookService.books();
		
		assertFalse(listOfBooks.isEmpty(), () -> "List of Books is Empty");
	}
	
	
	
	@Test 
	public void assertFalseWithSupplierAndMessageSupplier() {
		BookService bookService = new BookService() ;
		
		Book book1 = new Book("1", "Basic Java", "Wrox");
		bookService.addBook(book1);
		
		List<Book> listOfBooks = bookService.books();
		
		assertFalse(() -> listOfBooks.isEmpty(), () -> "List of Books is Empty");
	}
	
	
	
}

