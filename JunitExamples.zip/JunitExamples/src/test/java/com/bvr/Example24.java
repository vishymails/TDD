package com.bvr;




import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;

import com.bvr.mockito2.AuthenticationService;
import com.bvr.mockito2.LoginController;

@TestInstance(Lifecycle.PER_CLASS)
public class Example24 {

    private LoginController controller;   // SUT

    private AuthenticationService service;   // mock

    @BeforeAll
    public void setUp() throws Exception {
        this.service = Mockito.mock(AuthenticationService.class);
        this.controller = new LoginController(this.service);
    }

    @Test
    public void testService_validUsernameAndPassword_logsInUser() {
        // arrange
        when(service.authenticate(anyString(), anyString())).thenReturn(true);

        // act
        String viewPath = controller.service("tom", "password123");

        // assert
        assertNotNull(viewPath);
        assertEquals("/home", viewPath);
    }
}