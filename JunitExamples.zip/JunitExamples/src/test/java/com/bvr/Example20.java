package com.bvr;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

import com.bvr.order.TestOrderService;
import com.bvr.payment.TestPaymentService;
import com.bvr.user.TestUserService;

@RunWith(JUnitPlatform.class)
@SelectClasses({TestUserService.class, TestOrderService.class, TestPaymentService.class})
public class Example20 {

}
