package com.bvr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeFalse;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

public class Example7 {

	@Test
	public void assumeTrueWithNoMessage() {
		assumeTrue("DEV".equals(System.getProperty("ENV")));
		
		System.out.println("Assumption Passed");
		
		assertEquals(3, 2+1);
	}
	
	
	@Test
	public void assumeTrueWithMessage() {
		assumeTrue("DEV".equals(System.getProperty("ENV")), "Assumption Failed!");
		
		System.out.println("Assumption Passed");
		
		assertEquals(3, 2+1);
	}
	
	
	@Test
	public void assumeFalseWithNoMessage() {
		assumeFalse("DEV".equals(System.getProperty("ENV")));
		
		System.out.println("Assumption Passed");
		
		assertEquals(3, 2+1);
	}
	
	
	@Test
	public void assumeFalseWithMessage() {
		assumeFalse("DEV".equals(System.getProperty("ENV")), "Assumption Failed!");
		
		System.out.println("Assumption Passed");
		
		assertEquals(3, 2+1);
	}
}
