package com.bvr;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

import com.bvr.model.Book;
import com.bvr.service.BookService;

public class Example4 {

	@Test
	public void assertNotEqualsWithNoMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		Book actualBook = bookService.getBookById("1");
		
		assertNotEquals("2", actualBook.getBookId());		
		
	}
	
	
	@Test
	public void assertNotEqualsWithMessage() {
		Book book1 = new Book("1", "Basic Java", "SunPress");
		Book book2 = new Book("2", "Head First Design Patterns", "Packt");
		
		BookService bookService = new BookService();
		
		bookService.addBook(book1);
		bookService.addBook(book2);
		
		Book actualBook = bookService.getBookById("1");
		
		assertNotEquals("2", actualBook.getBookId(), "Book ID match to be expected ");		
		
	}
	
}
