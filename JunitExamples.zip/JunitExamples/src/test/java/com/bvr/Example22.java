package com.bvr;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.bvr.mockito.UserManager;
import com.bvr.mockito.UserService;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class Example22 {

	@Mock
	UserManager userManager;
	
	@Test
	public void testSaveArgMatch() throws Exception {
	
		final String name = "Vishwanath Rao";
		
		UserService userService = new UserService(userManager);
		
		userService.save(name);
		
		Mockito.verify(userManager, Mockito.times(1)).save(Mockito.anyString());
		Mockito.verify(userManager, Mockito.times(1)).save(Mockito.isA(String.class));
		Mockito.verify(userManager, Mockito.times(1)).save(Mockito.startsWith("Vi"));
		Mockito.verify(userManager, Mockito.times(1)).save(Mockito.endsWith("ao"));
		
	}
}
